<?php
require_once '../config/config.php';

// --- Date Filter ---
$date_from = $_GET['from'] ?? date('Y-m-d');
$date_to   = $_GET['to'] ?? date('Y-m-d');

if ($date_from > $date_to) {
    [$date_from, $date_to] = [$date_to, $date_from];
}

// --- JSON API HANDLER ---
if (isset($_GET['section'])) {
    header('Content-Type: application/json');

    $section = $_GET['section'];

    if ($section === 'tests') {
        $stmt = $conn->prepare("
            SELECT test_name, COUNT(*) as cnt
            FROM lab_orders
            WHERE status = 'completed'
            AND DATE(entered_at) BETWEEN ? AND ?
            GROUP BY test_name
            ORDER BY cnt DESC
        ");
    }

    elseif ($section === 'departments') {
        $stmt = $conn->prepare("
            SELECT d.name, COUNT(*) as cnt
            FROM lab_orders lo
            JOIN visits v ON lo.visit_id = v.id
            JOIN departments d ON v.department_id = d.id
            WHERE lo.status = 'completed'
            AND DATE(lo.entered_at) BETWEEN ? AND ?
            GROUP BY d.name
            ORDER BY cnt DESC
        ");
    }

    elseif ($section === 'doctors') {
        $stmt = $conn->prepare("
            SELECT COALESCE(doc.name, 'Unassigned') as name, COUNT(*) as cnt
            FROM lab_orders lo
            JOIN visits v ON lo.visit_id = v.id
            LEFT JOIN doctors doc ON v.doctor_id = doc.id
            WHERE lo.status = 'completed'
            AND DATE(lo.entered_at) BETWEEN ? AND ?
            GROUP BY doc.name
            ORDER BY cnt DESC
        ");
    }

    $stmt->bind_param("ss", $date_from, $date_to);
    $stmt->execute();

    echo json_encode($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    exit;
}

// --- SUMMARY STATS ---
$stmt = $conn->prepare("
    SELECT COUNT(*) as cnt 
    FROM lab_orders 
    WHERE status = 'completed'
    AND DATE(ordered_at) BETWEEN ? AND ?
");
$stmt->bind_param("ss", $date_from, $date_to);
$stmt->execute();
$total_tests = $stmt->get_result()->fetch_assoc()['cnt'];

$stmt = $conn->prepare("
    SELECT COUNT(DISTINCT visit_id) as cnt
    FROM lab_orders
    WHERE status = 'completed'
    AND DATE(ordered_at) BETWEEN ? AND ?
");
$stmt->bind_param("ss", $date_from, $date_to);
$stmt->execute();
$unique_patients = $stmt->get_result()->fetch_assoc()['cnt']; // FIX: was fetched but never used below

// --- DETAILED RESULTS ---
$stmt = $conn->prepare("
    SELECT lo.test_name, lr.results, lr.remarks, lr.entered_at,
           p.name as patient_name,
           d.name as department_name,
           COALESCE(doc.name, 'N/A') as doctor_name
    FROM lab_orders lo
    JOIN visits v ON lo.visit_id = v.id
    JOIN patients p ON v.patient_id = p.id
    JOIN departments d ON v.department_id = d.id
    LEFT JOIN doctors doc ON v.doctor_id = doc.id
    LEFT JOIN lab_results lr ON lr.lab_order_id = lo.id
    WHERE lo.status = 'completed'
    AND DATE(lr.entered_at) BETWEEN ? AND ?
    ORDER BY lr.entered_at DESC
");
$stmt->bind_param("ss", $date_from, $date_to);
$stmt->execute();
$results = $stmt->get_result();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en" class="light scroll-smooth group" data-layout="vertical" data-sidebar="light" data-sidebar-size="lg" data-mode="light" data-topbar="light" data-skin="default" data-navbar="sticky" data-content="fluid" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Lab Reports | MediFlow OPD</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <link rel="shortcut icon" href="../assets/images/favicon.ico">
    <script src="../assets/js/layout.js"></script>
    <link rel="stylesheet" href="../assets/css/starcode2.css">
    <style>
        [x-cloak] { display: none !important; }
        .chart-bar-bg { height: 8px; border-radius: 4px; background: #e2e8f0; overflow: hidden; }
        .chart-bar-fill { height: 100%; border-radius: 4px; background: currentColor; transition: width 0.3s; }
    </style>
</head>

<body class="text-base bg-body-bg text-body font-public dark:text-zink-100 dark:bg-zink-800 group-data-[skin=bordered]:bg-body-bordered group-data-[skin=bordered]:dark:bg-zink-700">
<div class="group-data-[sidebar-size=sm]:min-h-sm group-data-[sidebar-size=sm]:relative">

<?php include 'sidenav.php'; ?>
<?php include 'topnav.php'; ?>

<div class="relative min-h-screen group-data-[sidebar-size=sm]:min-h-sm">

    <div class="group-data-[sidebar-size=lg]:ltr:md:ml-vertical-menu group-data-[sidebar-size=lg]:rtl:md:mr-vertical-menu group-data-[sidebar-size=md]:ltr:ml-vertical-menu-md group-data-[sidebar-size=md]:rtl:mr-vertical-menu-md group-data-[sidebar-size=sm]:ltr:ml-vertical-menu-sm group-data-[sidebar-size=sm]:rtl:mr-vertical-menu-sm pt-[calc(theme('spacing.header')_*_1)] pb-[calc(theme('spacing.header')_*_0.8)] px-4 group-data-[navbar=bordered]:pt-[calc(theme('spacing.header')_*_1.3)] group-data-[navbar=hidden]:pt-0 group-data-[layout=horizontal]:mx-auto group-data-[layout=horizontal]:max-w-screen-2xl group-data-[layout=horizontal]:px-0 group-data-[layout=horizontal]:group-data-[sidebar-size=lg]:ltr:md:ml-auto group-data-[layout=horizontal]:group-data-[sidebar-size=lg]:rtl:md:mr-auto group-data-[layout=horizontal]:md:pt-[calc(theme('spacing.header')_*_1.6)] group-data-[layout=horizontal]:px-3 group-data-[layout=horizontal]:group-data-[navbar=hidden]:pt-[calc(theme('spacing(header')_*_0.9)]">
        <div class="container-fluid group-data-[content=boxed]:max-w-boxed mx-auto">

            <!-- Breadcrumb -->
            <div class="flex flex-col gap-2 py-4 md:flex-row md:items-center print:hidden">
                <div class="grow">
                    <h5 class="text-16">Lab Reports</h5>
                </div>
                <ul class="flex items-center gap-2 text-sm font-normal shrink-0">
                    <li class="relative before:content-['\ea54'] before:font-remix ltr:before:-right-1 rtl:before:-left-1 before:absolute before:text-[18px] before:-top-[3px] ltr:pr-4 rtl:pl-4 before:text-slate-400 dark:text-zink-200">
                        <a href="../../index.php" class="text-slate-400 dark:text-zink-200">Home</a>
                    </li>
                    <li class="relative before:content-['\ea54'] before:font-remix ltr:before:-right-1 rtl:before:-left-1 before:absolute before:text-[18px] before:-top-[3px] ltr:pr-4 rtl:pl-4 before:text-slate-400 dark:text-zink-200">
                        <a href="index.php" class="text-slate-400 dark:text-zink-200">Lab</a>
                    </li>
                    <li class="text-slate-700 dark:text-zink-100">Reports</li>
                </ul>
            </div>

            <!-- Date Filter -->
            <div class="card mb-5">
                <div class="card-body">
                    <div class="flex items-center gap-3">
                        <div class="flex items-center justify-center size-8 rounded-full bg-custom-500 text-white shrink-0">
                            <i data-lucide="calendar" class="size-4"></i>
                        </div>
                        <!-- FIX: submitUrl and resetDates defined as proper methods, not strings -->
                        <div x-data="{
                            from: '<?= $date_from ?>',
                            to: '<?= $date_to ?>',
                            submitUrl() {
                                window.location.href = 'reports.php?from=' + this.from + '&to=' + this.to;
                            },
                            resetDates() {
                                const today = new Date().toISOString().split('T')[0];
                                this.from = today;
                                this.to = today;
                                this.submitUrl();
                            }
                        }" x-cloak>
                            <div class="flex flex-wrap items-center gap-2 grow">
                                <div class="relative grow">
                                    <label class="block mb-1.5 text-sm font-medium text-slate-700 dark:text-zink-200">From</label>
                                    <input type="date" x-model="from"
                                           class="form-input border-slate-200 dark:border-zink-500 focus:outline-none focus:border-custom-500 dark:text-zink-100 dark:bg-zink-700 dark:focus:border-custom-800">
                                </div>
                                <span class="text-slate-400 dark:text-zink-200 self-center">to</span>
                                <div class="relative grow">
                                    <label class="block mb-1.5 text-sm font-medium text-slate-700 dark:text-zink-200">To</label>
                                    <input type="date" x-model="to"
                                           class="form-input border-slate-200 dark:border-zink-500 focus:outline-none focus:border-custom-500 dark:text-zink-100 dark:bg-zink-700 dark:focus:border-custom-800">
                                </div>
                            </div>
                            <button type="button" @click="submitUrl()" class="px-4 py-[9px] text-white btn bg-custom-500 border-custom-500 hover:bg-custom-600 transition-colors shrink-0">
                                <i data-lucide="filter" class="inline-block size-4 ltr:mr-1 rtl:ml-1"></i> Filter
                            </button>
                            <button type="button" @click="resetDates()" class="px-4 py-[9px] text-slate-500 btn bg-white border-slate-200 hover:text-slate-600 hover:bg-slate-50 dark:bg-zink-700 dark:text-zink-200 dark:border-zink-500 dark:hover:text-zink-100 dark:hover:bg-zink-600 shrink-0">
                                <i data-lucide="x" class="inline-block size-4 ltr:mr-1 rtl:ml-1"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Summary Stats -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-5">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="flex items-center justify-center mx-auto mb-2 size-12 rounded-full bg-purple-100 dark:bg-purple-500/20">
                            <i data-lucide="flask-conical" class="size-6 text-purple-500"></i>
                        </div>
                        <p class="text-slate-500 dark:text-zink-200 text-sm">Total Tests</p>
                        <h3 class="text-2xl font-bold mt-1"><?= $total_tests ?></h3>
                        <p class="text-xs text-slate-400 dark:text-zink-300">In selected period</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <div class="flex items-center justify-center mx-auto mb-2 size-12 rounded-full bg-green-100 dark:bg-green-500/20">
                            <!-- FIX: typo data-lucive -> data-lucide -->
                            <i data-lucide="user-check" class="size-6 text-green-500"></i>
                        </div>
                        <p class="text-slate-500 dark:text-zink-200 text-sm">Unique Patients</p>
                        <!-- FIX: was $completed_tests (undefined), correct var is $unique_patients -->
                        <h3 class="text-2xl font-bold mt-1"><?= $unique_patients ?></h3>
                        <p class="text-xs text-slate-400 dark:text-zink-300">Had lab tests done</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <div class="flex items-center justify-center mx-auto mb-2 size-12 rounded-full bg-yellow-100 dark:bg-yellow-500/20">
                            <i data-lucide="test-tube" class="size-6 text-yellow-500"></i>
                        </div>
                        <p class="text-slate-500 dark:text-zink-200 text-sm">Different Tests</p>
                        <!-- FIX: $test_breakdown never existed; count is loaded via AJAX so display dynamically -->
                        <h3 class="text-2xl font-bold mt-1" id="distinct-test-count">—</h3>
                        <p class="text-xs text-slate-400 dark:text-zink-300">Types of tests performed</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <div class="flex items-center justify-center mx-auto mb-2 size-12 rounded-full bg-sky-100 dark:bg-sky-500/20">
                            <i data-lucide="calendar-check" class="size-6 text-sky-500"></i>
                        </div>
                        <p class="text-slate-500 dark:text-zink-200 text-sm">Date Range</p>
                        <!-- FIX: broken nested echo tags and malformed string concatenation -->
                        <h3 class="text-lg font-bold mt-1"><?= date('d M Y', strtotime($date_from)) ?> — <?= date('d M Y', strtotime($date_to)) ?></h3>
                        <p class="text-xs text-slate-400 dark:text-zink-300"><?= date('D', strtotime($date_from)) ?> — <?= date('D', strtotime($date_to)) ?></p>
                    </div>
                </div>
            </div>

            <!-- Test-wise Breakdown -->
            <div class="card mb-5">
                <div class="card-body">
                    <h6 class="text-15 mb-4">Tests Performed</h6>
                    <!-- FIX: added .json() to fetch; API returns array directly (not r.results); index display moved to JS -->
                    <div class="space-y-3" x-data="{ results: [] }" x-init="
                        fetch('reports.php?from=<?= $date_from ?>&to=<?= $date_to ?>&section=tests')
                            .then(r => r.json())
                            .then(data => {
                                results = data;
                                document.getElementById('distinct-test-count').textContent = data.length;
                            });
                    ">
                        <template x-for="(item, index) in results" :key="index">
                            <div class="flex items-center gap-3 p-3 rounded-md border border-slate-200 dark:border-zink-500 hover:bg-slate-50 dark:hover:bg-zink-600 transition-colors">
                                <div class="flex items-center justify-center size-10 rounded-md bg-purple-100 dark:bg-purple-500/20 shrink-0">
                                    <!-- FIX: index display must be Alpine x-text, not PHP echo -->
                                    <span class="text-xs font-bold text-purple-600 dark:text-purple-400" x-text="index + 1"></span>
                                </div>
                                <div class="grow min-w-0">
                                    <p class="text-sm font-medium" x-text="item.test_name"></p>
                                    <!-- FIX: bar fill is a separate inner div; style and text were wrongly on the container -->
                                    <div class="chart-bar-bg mt-1.5 w-full">
                                        <div class="chart-bar-fill text-purple-500"
                                             :style="'width: ' + ((results[0]?.cnt ? (item.cnt / results[0].cnt) : 0) * 100) + '%'"></div>
                                    </div>
                                </div>
                                <span class="text-sm font-bold text-purple-600 dark:text-purple-400 shrink-0 w-12 text-right" x-text="item.cnt"></span>
                            </div>
                        </template>
                    </div>
                </div>
            </div>

            <!-- Department-wise Breakdown -->
            <div class="card mb-5">
                <div class="card-body">
                    <h6 class="text-15 mb-4">Department-wise Distribution</h6>
                    <!-- FIX: added .json(); percent() helper defined inline; closing tag was </div> not </template> -->
                    <div class="space-y-3" x-data="{ results: [] }" x-init="
                        fetch('reports.php?from=<?= $date_from ?>&to=<?= $date_to ?>&section=departments')
                            .then(r => r.json())
                            .then(data => { results = data; });
                    ">
                        <template x-for="(item, index) in results" :key="index">
                            <div class="flex items-center gap-3 p-3 rounded-md border border-slate-200 dark:border-zink-500 hover:bg-slate-50 dark:hover:bg-zink-600 transition-colors">
                                <div class="flex items-center justify-center size-10 rounded-md bg-custom-100 dark:bg-custom-500/20 shrink-0">
                                    <i data-lucide="building" class="size-5 text-custom-500"></i>
                                </div>
                                <div class="grow min-w-0">
                                    <p class="text-sm font-medium" x-text="item.name"></p>
                                    <div class="chart-bar-bg mt-1.5 w-full">
                                        <!-- FIX: percent() replaced with inline calculation -->
                                        <div class="chart-bar-fill text-custom-500"
                                             :style="'width: ' + ((results[0]?.cnt ? (item.cnt / results[0].cnt) : 0) * 100) + '%'"></div>
                                    </div>
                                </div>
                                <span class="text-sm font-bold text-custom-500 shrink-0 w-12 text-right" x-text="item.cnt"></span>
                            </div>
                        </template>
                    </div>
                </div>
            </div>

            <!-- Doctor-wise Breakdown -->
            <div class="card mb-5">
                <div class="card-body">
                    <h6 class="text-15 mb-4">Doctor-wise Tests</h6>
                    <!-- FIX: added .json(); broken Math.min expression fixed; closing </div> -> </template> -->
                    <div class="space-y-3" x-data="{ results: [] }" x-init="
                        fetch('reports.php?from=<?= $date_from ?>&to=<?= $date_to ?>&section=doctors')
                            .then(r => r.json())
                            .then(data => { results = data; });
                    ">
                        <template x-for="(item, index) in results" :key="index">
                            <div class="flex items-center gap-3 p-3 rounded-md border border-slate-200 dark:border-zink-500 hover:bg-slate-50 dark:hover:bg-zink-600 transition-colors">
                                <div class="flex items-center justify-center size-10 rounded-md bg-sky-100 dark:bg-sky-500/20 shrink-0">
                                    <!-- FIX: index display moved to Alpine x-text -->
                                    <span class="text-xs font-bold text-sky-600 dark:text-sky-400" x-text="index + 1"></span>
                                </div>
                                <div class="grow min-w-0">
                                    <!-- FIX: missing closing paren on e(), and PHP echo in Alpine context replaced with x-text -->
                                    <p class="text-sm font-medium" x-text="item.name || 'Unassigned'"></p>
                                    <div class="chart-bar-bg mt-1.5 w-full">
                                        <!-- FIX: broken Math.min expression with PHP var interpolation fixed -->
                                        <div class="chart-bar-fill text-sky-500"
                                             :style="'width: ' + Math.min((results[0]?.cnt ? (item.cnt / results[0].cnt) : 0) * 100, 100) + '%'"></div>
                                    </div>
                                </div>
                                <span class="text-sm font-bold text-sky-600 dark:text-sky-400 shrink-0 w-12 text-right" x-text="item.cnt"></span>
                            </div>
                        </template>
                    </div>
                </div>
            </div>

            <!-- Detailed Results List -->
            <div class="card">
                <div class="card-body">
                    <h6 class="text-15 mb-4">All Results (<?= $results->num_rows ?>)</h6>

                    <div class="-mx-5 overflow-x-auto">
                        <table class="w-full whitespace-nowrap">
                            <thead class="ltr:text-left rtl:text-right bg-slate-100 text-slate-500 dark:text-zink-200 dark:bg-zink-600">
                                <tr>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Test Name</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Patient</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Dept</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Doctor</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Date</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Results</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($r = $results->fetch_assoc()): ?>
                                <tr>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm font-medium"><?= e($r['test_name']) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm"><?= e($r['patient_name']) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm"><?= e($r['department_name']) ?></td>
                                    <!-- FIX: missing closing paren on e() call -->
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm"><?= e($r['doctor_name'] ?? 'N/A') ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-xs text-slate-400 dark:text-zink-300"><?= date('d M Y', strtotime($r['entered_at'])) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-xs max-w-[200px] truncate"><?= $r['results'] ? e(substr($r['results'], 0, 80)) . '…' : '-' ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-xs text-slate-400 dark:text-zink-300 max-w-[150px] truncate"><?= e($r['remarks'] ?? '-') ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($results->num_rows === 0): ?>
                    <div class="py-12 text-center text-slate-400 dark:text-zink-300">
                        <i data-lucide="flask-conical" class="size-12 mx-auto mb-3 text-slate-300 dark:text-zink-400"></i>
                        <p>No lab results found for this period</p>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof lucide !== 'undefined') lucide.createIcons();
    });
    </script>

</body>
</html>