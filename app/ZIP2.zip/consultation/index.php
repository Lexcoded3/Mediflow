<?php
require_once '../config/config.php';

// Patients waiting for consultation (triage done)
 $waiting = $conn->query("
    SELECT v.visit_id, v.token_number, v.created_at, v.department_id,
           p.name as patient_name, p.phone, p.age, p.gender, p.patient_id,
           d.name as department_name, doc.name as doctor_name,
           t.priority, t.bp_systolic, t.bp_diastolic, t.temperature, t.pulse,
           t.chief_complaint, t.triaged_at
    FROM visits v
    JOIN patients p ON v.patient_id = p.id
    JOIN departments d ON v.department_id = d.id
    LEFT JOIN doctors doc ON v.doctor_id = doc.id
    LEFT JOIN triage t ON t.visit_id = v.id
    WHERE v.visit_date = CURDATE() AND v.status = 'triage'
    ORDER BY 
        CASE COALESCE(t.priority, 'green')
            WHEN 'red' THEN 1
            WHEN 'orange' THEN 2
            WHEN 'yellow' THEN 3
            ELSE 4
        END ASC,
        v.token_number ASC
");

// Currently being consulted
 $in_progress = $conn->query("
    SELECT v.visit_id, v.token_number, v.created_at,
           p.name as patient_name, p.age, p.gender,
           d.name as department_name, doc.name as doctor_name,
           t.priority,
           c.consulted_at
    FROM visits v
    JOIN patients p ON v.patient_id = p.id
    JOIN departments d ON v.department_id = d.id
    JOIN doctors doc ON v.doctor_id = doc.id
    LEFT JOIN triage t ON t.visit_id = v.id
    LEFT JOIN consultations c ON c.visit_id = v.id
    WHERE v.visit_date = CURDATE() AND v.status = 'consulting'
    ORDER BY c.consulted_at DESC
");

// Waiting for lab results
 $lab_waiting = $conn->query("
    SELECT v.visit_id, v.token_number,
           p.name as patient_name, p.age,
           d.name as department_name, doc.name as doctor_name,
           t.priority
    FROM visits v
    JOIN patients p ON v.patient_id = p.id
    JOIN departments d ON v.department_id = d.id
    JOIN doctors doc ON v.doctor_id = doc.id
    LEFT JOIN triage t ON t.visit_id = v.id
    WHERE v.visit_date = CURDATE() AND v.status = 'lab'
    ORDER BY v.token_number ASC
");

// Load doctors for filter
 $doctors_list = $conn->query("SELECT d.*, dep.name as department_name FROM doctors d JOIN departments dep ON d.department_id = dep.id WHERE d.status = 1 ORDER BY d.name");

 $flash = getFlash();

// function priorityDot($priority) {
//     $colors = ['red' => 'bg-red-500', 'orange' => 'bg-orange-500', 'yellow' => 'bg-yellow-500', 'green' => 'bg-green-500'];
//     $color = $colors[$priority] ?? 'bg-green-500';
//     return "<span class='inline-block size-2.5 rounded-full $color'></span>";
// }
?>
<!DOCTYPE html>
<html lang="en" class="light scroll-smooth group" data-layout="vertical" data-sidebar="light" data-sidebar-size="lg" data-mode="light" data-topbar="light" data-skin="default" data-navbar="sticky" data-content="fluid" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Consultation | MediFlow OPD</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <link rel="shortcut icon" href="../assets/images/favicon.ico">
    <script src="../assets/js/layout.js"></script>
    <link rel="stylesheet" href="../assets/css/starcode2.css">
</head>

<body class="text-base bg-body-bg text-body font-public dark:text-zink-100 dark:bg-zink-800 group-data-[skin=bordered]:bg-body-bordered group-data-[skin=bordered]:dark:bg-zink-700">
<div class="group-data-[sidebar-size=sm]:min-h-sm group-data-[sidebar-size=sm]:relative">

<?php include 'sidenav.php'; ?>
<?php include 'topnav.php'; ?>

<div class="relative min-h-screen group-data-[sidebar-size=sm]:min-h-sm">

    <div class="group-data-[sidebar-size=lg]:ltr:md:ml-vertical-menu group-data-[sidebar-size=lg]:rtl:md:mr-vertical-menu group-data-[sidebar-size=md]:ltr:ml-vertical-menu-md group-data-[sidebar-size=md]:rtl:mr-vertical-menu-md group-data-[sidebar-size=sm]:ltr:ml-vertical-menu-sm group-data-[sidebar-size=sm]:rtl:mr-vertical-menu-sm pt-[calc(theme('spacing.header')_*_1)] pb-[calc(theme('spacing.header')_*_0.8)] px-4 group-data-[navbar=bordered]:pt-[calc(theme('spacing.header')_*_1.3)] group-data-[navbar=hidden]:pt-0 group-data-[layout=horizontal]:mx-auto group-data-[layout=horizontal]:max-w-screen-2xl group-data-[layout=horizontal]:px-0 group-data-[layout=horizontal]:group-data-[sidebar-size=lg]:ltr:md:ml-auto group-data-[layout=horizontal]:group-data-[sidebar-size=lg]:rtl:md:mr-auto group-data-[layout=horizontal]:md:pt-[calc(theme('spacing.header')_*_1.6)] group-data-[layout=horizontal]:px-3 group-data-[layout=horizontal]:group-data-[navbar=hidden]:pt-[calc(theme('spacing.header')_*_0.9)]">
        <div class="container-fluid group-data-[content=boxed]:max-w-boxed mx-auto">

            <!-- Breadcrumb -->
            <div class="flex flex-col gap-2 py-4 md:flex-row md:items-center print:hidden">
                <div class="grow">
                    <h5 class="text-16">Consultation</h5>
                </div>
                <ul class="flex items-center gap-2 text-sm font-normal shrink-0">
                    <li class="relative before:content-['\ea54'] before:font-remix ltr:before:-right-1 rtl:before:-left-1 before:absolute before:text-[18px] before:-top-[3px] ltr:pr-4 rtl:pl-4 before:text-slate-400 dark:text-zink-200">
                        <a href="../../index.php" class="text-slate-400 dark:text-zink-200">Home</a>
                    </li>
                    <li class="relative before:content-['\ea54'] before:font-remix ltr:before:-right-1 rtl:before:-left-1 before:absolute before:text-[18px] before:-top-[3px] ltr:pr-4 rtl:pl-4 before:text-slate-400 dark:text-zink-200">
                        <a href="#!" class="text-slate-400 dark:text-zink-200">OPD</a>
                    </li>
                    <li class="text-slate-700 dark:text-zink-100">Consultation</li>
                </ul>
            </div>

            <?php if ($flash): ?>
            <div class="mb-4 px-4 py-3 rounded-md border <?= $flash['type'] === 'success' ? 'bg-green-50 border-green-200 text-green-600 dark:bg-green-500/10 dark:border-green-500/20 dark:text-green-400' : 'bg-red-50 border-red-200 text-red-600 dark:bg-red-500/10 dark:border-red-500/20 dark:text-red-400' ?>">
                <div class="flex items-center gap-2">
                    <i data-lucide="<?= $flash['type'] === 'success' ? 'check-circle' : 'alert-circle' ?>" class="size-5 shrink-0"></i>
                    <span><?= $flash['msg'] ?></span>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-5">
                <div class="card">
                    <div class="card-body">
                        <div class="flex items-center gap-3">
                            <div class="flex items-center justify-center size-12 rounded-md bg-yellow-100 dark:bg-yellow-500/20 shrink-0">
                                <i data-lucide="clock" class="size-6 text-yellow-500"></i>
                            </div>
                            <div class="grow">
                                <p class="text-slate-500 dark:text-zink-200 text-sm">Waiting</p>
                                <h4 class="mt-1 text-2xl font-bold"><?= $waiting->num_rows ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="flex items-center gap-3">
                            <div class="flex items-center justify-center size-12 rounded-md bg-sky-100 dark:bg-sky-500/20 shrink-0">
                                <i data-lucide="stethoscope" class="size-6 text-sky-500"></i>
                            </div>
                            <div class="grow">
                                <p class="text-slate-500 dark:text-zink-200 text-sm">In Progress</p>
                                <h4 class="mt-1 text-2xl font-bold"><?= $in_progress->num_rows ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="flex items-center gap-3">
                            <div class="flex items-center justify-center size-12 rounded-md bg-purple-100 dark:bg-purple-500/20 shrink-0">
                                <i data-lucide="flask-conical" class="size-6 text-purple-500"></i>
                            </div>
                            <div class="grow">
                                <p class="text-slate-500 dark:text-zink-200 text-sm">Awaiting Lab</p>
                                <h4 class="mt-1 text-2xl font-bold"><?= $lab_waiting->num_rows ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Waiting Queue -->
            <div class="card mb-5">
                <div class="card-body">
                    <div class="flex items-center justify-between mb-4">
                        <h6 class="text-15">Waiting for Consultation <span class="text-slate-400 dark:text-zink-200 font-normal">(<?= $waiting->num_rows ?>)</span></h6>
                    </div>

                    <?php if ($waiting->num_rows > 0): ?>
                    <div class="-mx-5 overflow-x-auto">
                        <table class="w-full whitespace-nowrap">
                            <thead class="ltr:text-left rtl:text-right bg-slate-100 text-slate-500 dark:text-zink-200 dark:bg-zink-600">
                                <tr>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500 w-16">Token</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Patient</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Department</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Assigned Doctor</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Vitals</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Complaint</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Priority</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Wait</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($w = $waiting->fetch_assoc()): 
                                    $wait_mins = round((time() - strtotime($w['triaged_at'])) / 60);
                                ?>
                                <tr class="<?= ($w['priority'] === 'red' || $w['priority'] === 'orange') ? 'bg-red-50/50 dark:bg-red-500/5' : '' ?>">
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500">
                                        <div class="flex items-center gap-1.5">
                                            <?= priorityDot($w['priority']) ?>
                                            <span class="font-bold"><?= str_pad($w['token_number'], 3, '0', STR_PAD_LEFT) ?></span>
                                        </div>
                                    </td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500">
                                        <p class="text-sm font-medium"><?= e($w['patient_name']) ?></p>
                                        <p class="text-xs text-slate-400 dark:text-zink-300"><?= e($w['age']) ?>y &middot; <?= e($w['gender']) ?></p>
                                    </td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm"><?= e($w['department_name']) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm"><?= e($w['doctor_name'] ?? '<span class="text-slate-400">Not assigned</span>') ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-xs">
                                        <span class="<?= $w['temperature'] > 37.5 ? 'text-red-500 font-medium' : '' ?>"><?= $w['temperature'] ?>°C</span>
                                        <span class="text-slate-400">|</span>
                                        <span class="<?= ($w['bp_systolic'] > 140 || $w['bp_diastolic'] > 90) ? 'text-red-500 font-medium' : '' ?>"><?= $w['bp_systolic'] ?>/<?= $w['bp_diastolic'] ?></span>
                                    </td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-xs text-slate-500 dark:text-zink-200 max-w-[150px] truncate"><?= e($w['chief_complaint'] ?: '-') ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500"><?= priorityDot($w['priority']) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-xs <?= $wait_mins > 30 ? 'text-red-500 font-medium' : 'text-slate-500 dark:text-zink-200' ?>"><?= $wait_mins ?> min</td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500">
                                        <a href="consult.php?visit_id=<?= urlencode($w['visit_id']) ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-white rounded-md bg-custom-500 hover:bg-custom-600 transition-colors">
                                            <i data-lucide="play" class="size-3"></i> Consult
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="py-12 text-center">
                        <i data-lucide="inbox" class="size-12 mx-auto mb-3 text-slate-300 dark:text-zink-400"></i>
                        <p class="text-slate-400 dark:text-zink-300">No patients waiting for consultation</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- In Progress -->
            <?php if ($in_progress->num_rows > 0): ?>
            <div class="card mb-5">
                <div class="card-body">
                    <h6 class="text-15 mb-4">Currently Being Consulted <span class="text-slate-400 dark:text-zink-200 font-normal">(<?= $in_progress->num_rows ?>)</span></h6>
                    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                        <?php while ($ip = $in_progress->fetch_assoc()): ?>
                        <div class="p-4 rounded-md border border-sky-200 dark:border-sky-500/30 bg-sky-50/50 dark:bg-sky-500/5">
                            <div class="flex items-start gap-3">
                                <div class="flex items-center justify-center size-10 rounded-full bg-sky-100 dark:bg-sky-500/20 shrink-0">
                                    <span class="text-sm font-bold text-sky-600 dark:text-sky-400"><?= str_pad($ip['token_number'], 3, '0', STR_PAD_LEFT) ?></span>
                                </div>
                                <div class="grow min-w-0">
                                    <h6 class="text-sm font-medium truncate"><?= e($ip['patient_name']) ?></h6>
                                    <p class="text-xs text-slate-500 dark:text-zink-200"><?= e($ip['doctor_name']) ?> &middot; <?= e($ip['department_name']) ?></p>
                                    <p class="text-[10px] text-slate-400 dark:text-zink-300 mt-1">Since <?= date('h:i A', strtotime($ip['consulted_at'])) ?></p>
                                </div>
                            </div>
                            <div class="mt-3 pt-3 border-t border-sky-200/50 dark:border-sky-500/20 flex gap-2">
                                <a href="consult.php?visit_id=<?= urlencode($ip['visit_id']) ?>" class="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 text-xs text-sky-600 dark:text-sky-400 bg-sky-100 dark:bg-sky-500/20 rounded-md hover:bg-sky-200 dark:hover:bg-sky-500/30 transition-colors">
                                    <i data-lucide="pencil" class="size-3"></i> Continue
                                </a>
                                <a href="prescribe.php?visit_id=<?= urlencode($ip['visit_id']) ?>" class="flex items-center justify-center gap-1 px-3 py-1.5 text-xs text-white bg-custom-500 rounded-md hover:bg-custom-600 transition-colors">
                                    <i data-lucide="file-text" class="size-3"></i> Rx
                                </a>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Lab Waiting -->
            <?php if ($lab_waiting->num_rows > 0): ?>
            <div class="card">
                <div class="card-body">
                    <h6 class="text-15 mb-4">Awaiting Lab Results <span class="text-slate-400 dark:text-zink-200 font-normal">(<?= $lab_waiting->num_rows ?>)</span></h6>
                    <div class="-mx-5 overflow-x-auto">
                        <table class="w-full whitespace-nowrap">
                            <thead class="ltr:text-left rtl:text-right bg-slate-100 text-slate-500 dark:text-zink-200 dark:bg-zink-600">
                                <tr>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Token</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Patient</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Doctor</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Priority</th>
                                    <th class="px-3.5 py-2.5 first:pl-5 last:pr-5 font-semibold border-y border-slate-200 dark:border-zink-500">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($lw = $lab_waiting->fetch_assoc()): ?>
                                <tr>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 font-medium"><?= str_pad($lw['token_number'], 3, '0', STR_PAD_LEFT) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm"><?= e($lw['patient_name']) ?> <span class="text-slate-400">(<?= e($lw['age']) ?>y)</span></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500 text-sm"><?= e($lw['doctor_name']) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500"><?= priorityDot($lw['priority']) ?></td>
                                    <td class="px-3.5 py-2.5 first:pl-5 last:pr-5 border-y border-slate-200 dark:border-zink-500">
                                        <a href="consult.php?visit_id=<?= urlencode($lw['visit_id']) ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-500/20 rounded-md hover:bg-purple-200 dark:hover:bg-purple-500/30 transition-colors">
                                            <i data-lucide="flask-conical" class="size-3"></i> Review Results
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>

    <?php include 'footer.php'; ?>

</body>
</html>